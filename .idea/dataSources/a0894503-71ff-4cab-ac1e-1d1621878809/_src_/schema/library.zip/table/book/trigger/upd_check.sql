CREATE TRIGGER upd_check
BEFORE UPDATE ON book
FOR EACH ROW
  BEGIN
   IF NEW.每千字价格=OLD.每千字价格 AND NEW.价格<>OLD.价格 THEN
         set NEW.每千字价格=NEW.价格/OLD.字数;
   ELSEIF NEW.每千字价格=OLD.每千字价格  AND NEW.字数<>OLD.字数 then
         set NEW.每千字价格=OLD.价格/NEW.字数;
 end if;
end;

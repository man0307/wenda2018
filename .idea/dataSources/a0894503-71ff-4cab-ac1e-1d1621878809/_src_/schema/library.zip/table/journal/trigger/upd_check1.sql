CREATE TRIGGER upd_check1
BEFORE UPDATE ON journal
FOR EACH ROW
  BEGIN
   IF NEW.平均单篇论文价格=OLD.平均单篇论文价格 AND NEW.价格<>OLD.价格 THEN
         set NEW.平均单篇论文价格=NEW.价格/OLD.每期论文数;
   ELSEIF NEW.平均单篇论文价格=OLD.平均单篇论文价格 AND NEW.每期论文数<>OLD.每期论文数 then
         set NEW.平均单篇论文价格=OLD.价格/NEW.每期论文数;
 end if;
end;
